﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System;
using System.Data;
using System.Net.Http;
using System.Threading.Tasks;
using Newtonsoft.Json;
using Microsoft.VisualBasic;

namespace Calculator_test
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		private double firstNumber = 0;
		private string operation = "";
		private bool isHistoryVisible = false;
		private string mode = "Standard";
		private bool isDarkMode = true;

		public MainWindow()
		{
			InitializeComponent();
		}
		private void ToggleTheme_Click(object sender, RoutedEventArgs e)
		{
			isDarkMode = !isDarkMode;

			var darkBrush = new SolidColorBrush(Color.FromRgb(30, 30, 30));
			var lightBrush = Brushes.White;
			var darkText = Brushes.White;
			var lightText = Brushes.Black;
			var darkBtnBg = new SolidColorBrush(Color.FromRgb(51, 51, 51));
			var lightBtnBg = Brushes.LightGray;

			if (isDarkMode)
			{
				// Dark Mode
				Resources["WindowBackground"] = darkBrush;
				Resources["TextColor"] = darkText;
				Resources["ButtonBackground"] = darkBtnBg;
				Resources["ButtonForeground"] = darkText;

				// Set background and text for the display, input, etc.
				Display.Background = Brushes.Black;
				Display.Foreground = Brushes.White;
				InputValue.Background = Brushes.Black;
				InputValue.Foreground = Brushes.White;
				ResultValue.Background = Brushes.Black;
				ResultValue.Foreground = Brushes.White;

				// Set history and sidebar colors for dark mode
				HistoryPanel.Background = darkBrush;
				HistoryList.Background = darkBrush;
				HistoryList.Foreground = Brushes.White;
				ToggleThemeButton.Content = "Light Mode";

				// Sidebar Colors
				Sidebar.Background = darkBrush;

				foreach (var child in Sidebar.Children)
				{
					if (child is Button button)
					{
						button.Background = darkBtnBg;
						button.Foreground = darkText;
						button.BorderBrush = darkBrush; // Set button border color
					}
				}

				// Show History button color for dark mode
				ToggleHistoryButton.Background = darkBtnBg;
				ToggleHistoryButton.Foreground = darkText;
				ToggleHistoryButton.BorderBrush = darkBrush; // Set border for the history button
				ToggleThemeButton.Background = darkBtnBg;
				ToggleThemeButton.Foreground = darkText;
			}
			else
			{
				// Light Mode
				Resources["WindowBackground"] = lightBrush;
				Resources["TextColor"] = lightText;
				Resources["ButtonBackground"] = lightBtnBg;
				Resources["ButtonForeground"] = lightText;

				// Set background and text for the display, input, etc.
				Display.Background = Brushes.LightGray;
				Display.Foreground = Brushes.Black;
				InputValue.Background = Brushes.White;
				InputValue.Foreground = Brushes.Black;
				ResultValue.Background = Brushes.White;
				ResultValue.Foreground = Brushes.Black;

				// Set history and sidebar colors for light mode
				HistoryPanel.Background = Brushes.LightGray;
				HistoryList.Background = Brushes.White;
				HistoryList.Foreground = Brushes.Black;
				ToggleThemeButton.Content = "Dark Mode";

				// Sidebar Colors
				Sidebar.Background = lightBrush;

				foreach (var child in Sidebar.Children)
				{
					if (child is Button button)
					{
						button.Background = lightBtnBg;
						button.Foreground = lightText;
						button.BorderBrush = lightBrush; // Set button border color for light mode
					}
				}

				// Show History button color for light mode
				ToggleHistoryButton.Background = lightBtnBg;
				ToggleHistoryButton.Foreground = lightText;
				ToggleHistoryButton.BorderBrush = lightBrush; // Set border for the history button
				ToggleThemeButton.Background = lightBtnBg;
				ToggleThemeButton.Foreground = lightText;
			}
		}

		private void UpdateButtonStyles(Brush foreground, Brush background)
		{
			foreach (var child in MainGrid.Children)
			{
				if (child is Button button)
				{
					button.Foreground = foreground;
					button.Background = background;
				}
				else if (child is Panel panel)
				{
					foreach (var subchild in panel.Children)
					{
						if (subchild is Button subButton)
						{
							subButton.Foreground = foreground;
							subButton.Background = background;
						}
					}
				}
			}
		}
		private void Display_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (string.IsNullOrWhiteSpace(Display.Text) || Display.Text == "0")
			{
				CalculationPreview.Text = ""; // Clear preview when input is empty
			}
			else
			{
				CalculationPreview.Text = Display.Text; // Show current expression
			}
		}

		private void ToggleMenu_Click(object sender, RoutedEventArgs e)
		{
			if (Sidebar.Visibility == Visibility.Visible)
			{
				Sidebar.Visibility = Visibility.Collapsed;
				SmallMenuButton.Visibility = Visibility.Visible;
			}
			else
			{
				Sidebar.Visibility = Visibility.Visible;
				SmallMenuButton.Visibility = Visibility.Collapsed;
			}
		}
		private void ToggleHistory_Click(object sender, RoutedEventArgs e)
		{
			isHistoryVisible = !isHistoryVisible;
			HistoryPanel.Visibility = isHistoryVisible ? Visibility.Visible : Visibility.Collapsed;
			ToggleHistoryButton.Content = isHistoryVisible ? "Hide History" : "Show History";
			MainGrid.ColumnDefinitions[2].Width = isHistoryVisible ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
		}
		private async void Number_Click(object sender, RoutedEventArgs e)
		{
			Button button = sender as Button;
			if (button != null)
			{
				string buttonText = button.Content.ToString();

				if (ConversionPanel.Visibility == Visibility.Visible) // If Converter Mode is active
				{
					if (InputValue.Text == "0")
						InputValue.Text = buttonText;
					else
						InputValue.Text += buttonText;

					ResultValue.Text = (await ConvertValue()).ToString("F2"); // Auto-update conversion result
				}
				else // Standard Calculator Mode
				{
					// If display is "0", replace it (except for parentheses)
					if (Display.Text == "0" && buttonText != "(" && buttonText != ")")
						Display.Text = buttonText;
					else
					{
						// Add multiplication sign if a number is followed by an opening parenthesis
						if (char.IsDigit(Display.Text.Last()) && buttonText == "(")
							Display.Text += "*";

						Display.Text += buttonText;
					}

					CalculationPreview.Text = Display.Text; // Keep updating preview for calculations
				}
			}
		}

		private void Operator_Click(object sender, RoutedEventArgs e)
		{
			Button button = sender as Button;
			if (button != null)
			{
				string op = button.Content.ToString();

				// Prevent duplicate operators
				if (!string.IsNullOrEmpty(Display.Text) && "+-*/".Contains(Display.Text.Last()))
				{
					Display.Text = Display.Text.Remove(Display.Text.Length - 1) + op;
				}
				else
				{
					Display.Text += op;
				}
			}
			CalculationPreview.Text = Display.Text;
		}

		private void Equal_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				string expression = Display.Text;

				// Use DataTable to evaluate complex mathematical expressions
				DataTable dt = new DataTable();
				var result = dt.Compute(expression, "");

				Display.Text = result.ToString();
				CalculationPreview.Text = expression + " = ";
				// Add result to history
				string historyEntry = $"{expression} = {result}";
				HistoryList.Items.Insert(0, historyEntry);
			}
			catch (Exception ex)
			{
				MessageBox.Show("Invalid input. Please check your expression.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void Percentage_Click(object sender, RoutedEventArgs e)
		{
			double currentValue = double.Parse(Display.Text);
			double percentageValue = firstNumber * (currentValue / 100);
			Display.Text = percentageValue.ToString();
		}

		private void Sqrt_Click(object sender, RoutedEventArgs e)
		{
			if (Display.Visibility == Visibility.Visible)
			{
				double number = double.Parse(Display.Text);
				Display.Text = number >= 0 ? Math.Sqrt(number).ToString() : "Error";
			}
		}
		private void Square_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				double num = double.Parse(Display.Text);
				Display.Text = (num * num).ToString();
			}
			catch
			{
				MessageBox.Show("Invalid input", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void Reciprocal_Click(object sender, RoutedEventArgs e)
		{
			try
			{
				double num = double.Parse(Display.Text);
				if (num == 0)
					Display.Text = "Error";
				else
					Display.Text = (1 / num).ToString();
			}
			catch
			{
				MessageBox.Show("Invalid input", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void ClearEntry_Click(object sender, RoutedEventArgs e)
		{
			if (Display.Visibility == Visibility.Visible)
			{
				Display.Text = "0";
				CalculationPreview.Text = ""; // Clear preview when CE is pressed
			}
			else
			{
				InputValue.Text = "0";
			}
		}

		private void Backspace_Click(object sender, RoutedEventArgs e)
		{
			if (Display.Visibility == Visibility.Visible)
			{
				if (Display.Text.Length > 1)
				{
					Display.Text = Display.Text[..^1];
				}
				else
				{
					Display.Text = "0";
					CalculationPreview.Text = ""; // Clear preview when all input is deleted
				}
			}
			else
			{
				InputValue.Text = InputValue.Text.Length > 1 ? InputValue.Text[..^1] : "0";
			}
		}

		private void Standard_Click(object sender, RoutedEventArgs e)
		{
			mode = "Standard";
			ConversionPanel.Visibility = Visibility.Collapsed;
			DateCalculationPanel.Visibility = Visibility.Collapsed;
			Display.Visibility = Visibility.Visible;
			CalculationPreview.Visibility = Visibility.Visible;
			ScientificPanel.Visibility = Visibility.Collapsed;
			ProgrammerPanel.Visibility = Visibility.Collapsed;
		}

		private void Scientific_Click(object sender, RoutedEventArgs e)
		{
			mode = "Scientific";
			ConversionPanel.Visibility = Visibility.Collapsed;
			DateCalculationPanel.Visibility = Visibility.Collapsed;
			Display.Visibility = Visibility.Visible;
			CalculationPreview.Visibility = Visibility.Visible;
			ScientificPanel.Visibility = Visibility.Visible;
			ProgrammerPanel.Visibility = Visibility.Collapsed;
		}

		private void Graphing_Click(object sender, RoutedEventArgs e)
		{
			mode = "Graphing";
			ConversionPanel.Visibility = Visibility.Collapsed;
			DateCalculationPanel.Visibility = Visibility.Collapsed;
			Display.Visibility = Visibility.Visible;
			CalculationPreview.Visibility = Visibility.Visible;
			MessageBox.Show("Graphing Calculator Mode Enabled (Coming Soon!)");
		}

		private void Programmer_Click(object sender, RoutedEventArgs e)
		{
			mode = "Programmer";
			ConversionPanel.Visibility = Visibility.Collapsed;
			DateCalculationPanel.Visibility = Visibility.Collapsed;
			Display.Visibility = Visibility.Visible;
			CalculationPreview.Visibility = Visibility.Visible;
			ScientificPanel.Visibility = Visibility.Collapsed;
			ProgrammerPanel.Visibility = Visibility.Visible;
		}

		private void DateCalculation_Click(object sender, RoutedEventArgs e)
		{
			mode = "Date Calculation";
			ConversionPanel.Visibility = Visibility.Collapsed;
			Display.Visibility = Visibility.Collapsed;
			DateCalculationPanel.Visibility = Visibility.Visible;
			CalculationPreview.Visibility = Visibility.Collapsed;
		}
		private void CalculateDifference_Click(object sender, RoutedEventArgs e)
		{
			DateTime fromDate = FromDate.SelectedDate ?? DateTime.Now;
			DateTime toDate = ToDate.SelectedDate ?? DateTime.Now;
			TimeSpan difference = toDate - fromDate;
			DifferenceText.Text = $"Difference: {difference.Days} days";
		}
		// Scientific Button Logic
		private void ScientificFunction_Click(object sender, RoutedEventArgs e)
		{
			string func = (sender as Button)?.Content.ToString();
			double input = double.Parse(Display.Text);
			double result = 0;

			switch (func)
			{
				case "sin":
					result = Math.Sin(input);
					break;
				case "cos":
					result = Math.Cos(input);
					break;
				case "tan":
					result = Math.Tan(input);
					break;
				case "log":
					result = Math.Log10(input);
					break;
				case "ln":
					result = Math.Log(input);
					break;
				case "exp":
					result = Math.Exp(input);
					break;
				case "π":
					result = Math.PI;
					break;
				case "x²":
					result = Math.Pow(input, 2);
					break;
				case "^":
					result = Math.Pow(input, 2); // You can change the exponent logic here as needed
					break;
				case "1/x":
					result = 1 / input;
					break;
				case "e":
					result = Math.Exp(1); // Euler's constant
					break;
				case "!":
					result = Factorial((int)input);
					break;
			}

			Display.Text = result.ToString();
		}
		private int Factorial(int num)
		{
			if (num <= 1)
				return 1;
			return num * Factorial(num - 1);
		}


		private void ProgrammerFunction_Click(object sender, RoutedEventArgs e)
		{
			string func = (sender as Button)?.Content.ToString();
			if (!int.TryParse(Display.Text, out int value))
			{
				MessageBox.Show("Invalid input for Programmer functions.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
				return;
			}

			string result = "";

			try
			{
				switch (func)
				{
					case "BIN":
						result = Convert.ToString(value, 2);
						break;

					case "HEX":
						result = Convert.ToString(value, 16).ToUpper();
						break;

					case "DEC":
						result = value.ToString();
						break;

					case "NOT":
						result = (~value).ToString();
						break;

					case "AND":
					case "OR":
					case "XOR":
					case "<<":
					case ">>":
						// Prompt for second operand
						string input = Interaction.InputBox($"Enter second value for {func}:", $"{func} Operation", "1");
						if (!int.TryParse(input, out int operand))
						{
							MessageBox.Show("Invalid second value.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
							return;
						}

						switch (func)
						{
							case "AND":
								result = (value & operand).ToString();
								break;
							case "OR":
								result = (value | operand).ToString();
								break;
							case "XOR":
								result = (value ^ operand).ToString();
								break;
							case "<<":
								result = (value << operand).ToString();
								break;
							case ">>":
								result = (value >> operand).ToString();
								break;
						}
						break;
				}

				Display.Text = result;
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
		}

		private void EnableConverter(string title, string[] units)
		{
			mode = title;
			ConversionTitle.Text = title;

			ConversionPanel.Visibility = Visibility.Visible;
			Display.Visibility = Visibility.Collapsed;
			DateCalculationPanel.Visibility = Visibility.Collapsed;
			CalculationPreview.Visibility = Visibility.Collapsed;
			ScientificPanel.Visibility = Visibility.Collapsed;
			ProgrammerPanel.Visibility = Visibility.Collapsed;

			InputValue.Text = "0"; // Reset input field
			ResultValue.Text = "0.00"; // Reset result

			FromUnit.Items.Clear();
			ToUnit.Items.Clear();

			foreach (var unit in units)
			{
				FromUnit.Items.Add(unit);
				ToUnit.Items.Add(unit);
			}
			if (FromUnit.Items.Count > 0) FromUnit.SelectedIndex = 0;
			if (ToUnit.Items.Count > 1) ToUnit.SelectedIndex = 1;
		}

		private void Length_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Length", new string[]
			{
		"Inches", "Centimeters", "Meters", "Feet", "Kilometers", "Miles"
			});
		}

		private void WeightMass_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Weight & Mass", new string[]
			{
		"Kilograms", "Pounds", "Grams", "Ounces", "Stone", "Tons"
			});
		}

		private void Currency_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Currency", new string[]
			{
		"USD", "EUR", "VND", "GBP", "JPY", "CNY", "AUD", "CAD", "INR",
		"KRW", "SGD", "THB", "MYR", "CHF", "HKD", "NZD", "SEK", "NOK",
		"MXN", "ZAR", "RUB", "BRL", "TRY", "IDR", "TWD", "PLN", "DKK"
			});
		}

		private void Temperature_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Temperature", new string[]
			{
		"Celsius", "Fahrenheit", "Kelvin", "Rankine", "Delisle", "Newton"
			});
		}

		private void Volume_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Volume", new string[]
			{
		"Liters", "Milliliters", "Cubic Meters", "Cubic Feet", "Gallons",
		"Quarts", "Pints", "Cups"
			});
		}

		private void Energy_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Energy", new string[]
			{
		"Joules", "Kilojoules", "Calories", "Kilowatt-hours", "Electronvolts"
			});
		}

		private void Area_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Area", new string[]
			{
		"Square Meters", "Square Kilometers", "Square Feet", "Square Yards",
		"Acres", "Hectares", "Square Miles"
			});
		}

		private void Speed_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Speed", new string[]
			{
		"Meters per Second", "Kilometers per Hour", "Miles per Hour", "Knots",
		"Mach", "Feet per Second"
			});
		}

		private void Time_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Time", new string[]
			{
		"Seconds", "Minutes", "Hours", "Days", "Weeks", "Months", "Years"
			});
		}

		private void Power_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Power", new string[]
			{
		"Watts", "Kilowatts", "Horsepower", "Joules per Second", "BTUs per Hour"
			});
		}

		private void Data_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Data", new string[]
			{
		"Bytes", "Kilobytes", "Megabytes", "Gigabytes", "Terabytes",
		"Petabytes", "Exabytes"
			});
		}

		private void Pressure_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Pressure", new string[]
			{
		"Pascals", "Bar", "PSI", "Atmospheres", "Torr", "Millimeters of Mercury"
			});
		}

		private void Angle_Click(object sender, RoutedEventArgs e)
		{
			EnableConverter("Angle", new string[]
			{
		"Degrees", "Radians", "Gradians", "Arcminutes", "Arcseconds"
			});
		}

		private async void UnitChanged(object sender, SelectionChangedEventArgs e)
		{
			if (ResultValue != null)
				ResultValue.Text = (await ConvertValueAsync()).ToString("F2"); // Fetch live rates
		}

		private async Task<double> ConvertValue()
		{
			if (!double.TryParse(InputValue.Text, out double inputValue))
				return 0;

			double result = inputValue;
			if (FromUnit.SelectedItem == null || ToUnit.SelectedItem == null)
				return result;

			string fromUnit = FromUnit.SelectedItem.ToString();
			string toUnit = ToUnit.SelectedItem.ToString();

			switch (mode)
			{
				case "Currency":
					// Fetch real-time exchange rate
					double exchangeRate = await GetExchangeRateAsync(fromUnit, toUnit);
					return inputValue * exchangeRate; // Apply live conversion rate

				case "Length":
					if (fromUnit == "Inches" && toUnit == "Centimeters")
						result = inputValue * 2.54;
					else if (fromUnit == "Centimeters" && toUnit == "Inches")
						result = inputValue / 2.54;
					else if (fromUnit == "Inches" && toUnit == "Meters")
						result = inputValue * 0.0254;
					else if (fromUnit == "Meters" && toUnit == "Inches")
						result = inputValue / 0.0254;
					else if (fromUnit == "Feet" && toUnit == "Meters")
						result = inputValue * 0.3048;
					else if (fromUnit == "Meters" && toUnit == "Feet")
						result = inputValue / 0.3048;
					else if (fromUnit == "Kilometers" && toUnit == "Miles")
						result = inputValue * 0.621371;
					else if (fromUnit == "Miles" && toUnit == "Kilometers")
						result = inputValue / 0.621371;
					break;

				case "Weight & Mass":
					if (fromUnit == "Kilograms" && toUnit == "Pounds")
						result = inputValue * 2.20462;
					else if (fromUnit == "Pounds" && toUnit == "Kilograms")
						result = inputValue / 2.20462;
					else if (fromUnit == "Grams" && toUnit == "Ounces")
						result = inputValue * 0.035274;
					else if (fromUnit == "Ounces" && toUnit == "Grams")
						result = inputValue / 0.035274;
					else if (fromUnit == "Kilograms" && toUnit == "Tons")
						result = inputValue / 1000;
					else if (fromUnit == "Tons" && toUnit == "Kilograms")
						result = inputValue * 1000;
					break;

				case "Temperature":
					if (fromUnit == "Celsius" && toUnit == "Fahrenheit")
						result = (inputValue * 9 / 5) + 32;
					else if (fromUnit == "Fahrenheit" && toUnit == "Celsius")
						result = (inputValue - 32) * 5 / 9;
					else if (fromUnit == "Celsius" && toUnit == "Kelvin")
						result = inputValue + 273.15;
					else if (fromUnit == "Kelvin" && toUnit == "Celsius")
						result = inputValue - 273.15;
					else if (fromUnit == "Rankine" && toUnit == "Kelvin")
						result = (inputValue - 491.67) * 5 / 9;
					else if (fromUnit == "Kelvin" && toUnit == "Rankine")
						result = inputValue * 9 / 5;
					break;

				case "Volume":
					if (fromUnit == "Liters" && toUnit == "Gallons")
						result = inputValue * 0.264172;
					else if (fromUnit == "Gallons" && toUnit == "Liters")
						result = inputValue / 0.264172;
					else if (fromUnit == "Cubic Meters" && toUnit == "Cubic Feet")
						result = inputValue * 35.3147;
					else if (fromUnit == "Cubic Feet" && toUnit == "Cubic Meters")
						result = inputValue / 35.3147;
					break;

				case "Energy":
					if (fromUnit == "Joules" && toUnit == "Kilojoules")
						result = inputValue / 1000;
					else if (fromUnit == "Kilojoules" && toUnit == "Joules")
						result = inputValue * 1000;
					else if (fromUnit == "Calories" && toUnit == "Kilowatt-hours")
						result = inputValue / 860420;
					else if (fromUnit == "Kilowatt-hours" && toUnit == "Calories")
						result = inputValue * 860420;
					break;

				case "Area":
					if (fromUnit == "Square Meters" && toUnit == "Square Kilometers")
						result = inputValue / 1000000;
					else if (fromUnit == "Square Kilometers" && toUnit == "Square Meters")
						result = inputValue * 1000000;
					else if (fromUnit == "Acres" && toUnit == "Square Yards")
						result = inputValue * 4840;
					else if (fromUnit == "Square Yards" && toUnit == "Acres")
						result = inputValue / 4840;
					break;

				case "Speed":
					if (fromUnit == "Meters per Second" && toUnit == "Kilometers per Hour")
						result = inputValue * 3.6;
					else if (fromUnit == "Kilometers per Hour" && toUnit == "Meters per Second")
						result = inputValue / 3.6;
					else if (fromUnit == "Miles per Hour" && toUnit == "Knots")
						result = inputValue * 0.868976;
					else if (fromUnit == "Knots" && toUnit == "Miles per Hour")
						result = inputValue / 0.868976;
					break;

				case "Time":
					if (fromUnit == "Seconds" && toUnit == "Minutes")
						result = inputValue / 60;
					else if (fromUnit == "Minutes" && toUnit == "Seconds")
						result = inputValue * 60;
					else if (fromUnit == "Hours" && toUnit == "Days")
						result = inputValue / 24;
					else if (fromUnit == "Days" && toUnit == "Hours")
						result = inputValue * 24;
					break;

				case "Power":
					if (fromUnit == "Watts" && toUnit == "Kilowatts")
						result = inputValue / 1000;
					else if (fromUnit == "Kilowatts" && toUnit == "Watts")
						result = inputValue * 1000;
					else if (fromUnit == "Horsepower" && toUnit == "Watts")
						result = inputValue * 745.7;
					else if (fromUnit == "Watts" && toUnit == "Horsepower")
						result = inputValue / 745.7;
					break;

				case "Data":
					if (fromUnit == "Bytes" && toUnit == "Kilobytes")
						result = inputValue / 1024;
					else if (fromUnit == "Kilobytes" && toUnit == "Bytes")
						result = inputValue * 1024;
					else if (fromUnit == "Megabytes" && toUnit == "Gigabytes")
						result = inputValue / 1024;
					else if (fromUnit == "Gigabytes" && toUnit == "Megabytes")
						result = inputValue * 1024;
					break;

				case "Pressure":
					if (fromUnit == "Pascals" && toUnit == "Bar")
						result = inputValue / 100000;
					else if (fromUnit == "Bar" && toUnit == "Pascals")
						result = inputValue * 100000;
					else if (fromUnit == "PSI" && toUnit == "Atmospheres")
						result = inputValue / 14.696;
					else if (fromUnit == "Atmospheres" && toUnit == "PSI")
						result = inputValue * 14.696;
					break;

				case "Angle":
					if (fromUnit == "Degrees" && toUnit == "Radians")
						result = inputValue * (Math.PI / 180);
					else if (fromUnit == "Radians" && toUnit == "Degrees")
						result = inputValue * (180 / Math.PI);
					else if (fromUnit == "Degrees" && toUnit == "Gradians")
						result = inputValue * (200 / 180);
					else if (fromUnit == "Gradians" && toUnit == "Degrees")
						result = inputValue * (180 / 200);
					break;
			}

			return result;
		}

		private async Task<double> GetExchangeRateAsync(string fromCurrency, string toCurrency)
		{
			try
			{
				string apiKey = "768d9321000f5436f392ae8f";
				string url = $"https://v6.exchangerate-api.com/v6/768d9321000f5436f392ae8f/latest/{fromCurrency}";

				using (HttpClient client = new HttpClient())
				{
					HttpResponseMessage response = await client.GetAsync(url);
					if (response.IsSuccessStatusCode)
					{
						string jsonResponse = await response.Content.ReadAsStringAsync();
						dynamic data = JsonConvert.DeserializeObject(jsonResponse);

						if (data != null && data.conversion_rates != null)
						{
							return (double)data.conversion_rates[toCurrency];
						}
					}
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Failed to fetch exchange rates. Please check your internet connection.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
			}
			return 1; // Default to 1 if an error occurs
		}

		private static Dictionary<string, double> cachedRates = new Dictionary<string, double>();
		private static DateTime lastUpdated = DateTime.MinValue;

		private async Task<double> ConvertValueAsync()
		{
			try
			{
				// Ensure dropdowns have valid selections
				if (FromUnit.SelectedItem == null || ToUnit.SelectedItem == null)
					return 0; // Return 0 if selection is missing

				string fromCurrency = FromUnit.SelectedItem.ToString();
				string toCurrency = ToUnit.SelectedItem.ToString();

				if (string.IsNullOrWhiteSpace(fromCurrency) || string.IsNullOrWhiteSpace(toCurrency))
					return 0; // Avoid invalid selections

				if (!double.TryParse(InputValue.Text, out double amount))
					return 0; // Avoid parsing errors

				// Update rates every 1 hour instead of every calculation
				if (cachedRates.Count == 0 || (DateTime.Now - lastUpdated).TotalMinutes > 60)
				{
					string apiKey = "768d9321000f5436f392ae8f"; // Replace with actual API key
					string url = $"https://api.exchangerate-api.com/v4/768d9321000f5436f392ae8f/latest/{fromCurrency}";

					using (HttpClient client = new HttpClient())
					{
						HttpResponseMessage response = await client.GetAsync(url);
						if (response.IsSuccessStatusCode)
						{
							string json = await response.Content.ReadAsStringAsync();
							var data = JsonConvert.DeserializeObject<dynamic>(json);

							if (data.rates != null)
							{
								cachedRates.Clear();
								foreach (var rate in data.rates)
								{
									cachedRates[rate.Name] = (double)rate.Value;
								}
								lastUpdated = DateTime.Now;
							}
						}
					}
				}

				// Use cached rates instead of calling API every time
				if (cachedRates.ContainsKey(toCurrency))
				{
					double rate = cachedRates[toCurrency];
					return amount * rate;
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show("Error fetching currency rates: " + ex.Message);
			}

			return 0.00;
		}

		private async void InputValue_TextChanged(object sender, TextChangedEventArgs e)
		{
			if (ResultValue != null)
			{
				double convertedValue = await Task.Run(() => ConvertValue());
				ResultValue.Text = convertedValue.ToString("F2");
			}
		}
	}
}